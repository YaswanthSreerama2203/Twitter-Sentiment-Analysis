<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

<style>
body {
  font-family: "Lato", sans-serif;
}
.card {
  /* Add shadows to create the "card" effect */
  box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
  transition: 0.3s;
}

/* On mouse-over, add a deeper shadow */
.card:hover {
  box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2);
}

/* Add some padding inside the card container */
.container {
  padding: 2px 16px;
}

.sidenav {
  height: 100%;
  width: 200px;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  padding-top: 20px;
}

.sidenav a {
  padding: 8px 10px 8px 16px;
  text-decoration: none;
  font-size: 25px;
  color: #818181;
  display: block;
}

.sidenav a:hover {
  color: #f1f1f1;
}

.main {
  margin-left: 200px; /* Same as the width of the sidenav */
  font-size: 20px; /* Increased text to enable scrolling */
  padding: 0px 10px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
</head>
<body>

  <div class="sidenav">
  
    <a href="iCareBoard.php">iCareBoard</a>
    <a href="myboard.php">MyBoard</a>
    <a href="ManagePatients.php">Create Patient</a>
    <a href="Palette.php">Palette</a>
    <a href="login.php">Logout</a>

  </div>

<div class="main " align="center" >
  <?php
  $x=$_POST["editid"]; //edit button functionality
  $conn = mysqli_connect("localhost", "root", "", "icare") or die("Not Connected");
  $row=mysqli_query($conn, "SELECT   * FROM `patientrecord` WHERE ID=$x" ) or die ('Problem with query' . mysqli_error($conn));
  $res = mysqli_fetch_array($row,MYSQLI_ASSOC);
  $ID=$res["ID"];
  $name=$res["name"];
  $address=$res["address"];
  $DOB=$res["DOB"];
  $height=$res["height"];
  $weight=$res["weight"];
  $bloodGroup=$res["bloodGroup"];
  $bedID=$res["bedID"];
  $treatmentArea=$res["treatmentArea"];
  ?>
  <div class="card">
  <!DOCTYPE html>
  <html>
  <head>
  <title>Page Title</title>
  </head>
  <body>
  <!--To edit Patient Details Form-->
  <h2>Edit Patient</h2>
  <form method='post' action="iCareBoard.php">
    <div class="form-group">

  <p>
      <label>ID  &nbsp &nbsp &nbsp<input type="number" id="ID" name="ID" value=<?php echo $ID?> /></label>
    </p>
  <p>
      <label>name : <input type="text" id="name" name="name"value=<?php echo $name?> /></label>
    </p>

    <p>
        <label>DOB &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp<input type="date"  name="DOB" id="DOB" value=<?php echo $DOB?>></label>
      </p>
      <p>
        <label for="height">Height</label>
        <input type="number" step="0.01" id="height" name="height" value=<?php echo $height?>>
        </p>
        <p>
        <label>address : <input type="text" id="address" name="address" value=<?php echo $address ?>></label>
      </p>
        <p>
          <label for="weight">Weight in Pounds</label>
          <input type="number" step="0.01" id="weight" name="weight" value=<?php echo $weight?>>
          </p>
          <p>
          <label>bloodGroup : <input type="text" id="bloodGroup" name="bloodGroup"value=<?php echo $bloodGroup?> required/></label>
        </p>
      <p>
        <label>bedID &nbsp &nbsp &nbsp<input type="text" name="bedID" id="bedID"value=<?php echo $bedID?>></label>
      </p>
      <p>
        <label>treatmentArea : <input type="text" id="tarea" name="tarea"value=<?php echo $treatmentArea?>></label>
      </p>



  <p>
         <button type="submit" id="editbutton" name="editbutton"  >Confirm</button>&nbsp &nbsp

    </p>


  </form>
  </body>
  </html>
  <?php
    if(isset($_POST[""])) //post operation to update in the database
  {
    $pid=$_POST["ID"];
    $name=$_POST["name"];
    $address=$_POST["address"];
    $DOB=$_POST["DOB"];
    $height=$_POST["height"];
    $weight=$_POST["weight"];
    $bloodGroup=$_POST["bloodGroup"];
    $bedID=$_POST["bedID"];
    $trea=$_POST["tarea"];
    $conn = mysqli_connect("localhost", "root", "", "icare") or die("Not Connected");
    $role=mysqli_query($conn, "INSERT INTO `patientrecord` VALUES ('".$pid."', '".$name."','".$address."', '".$DOB."','".$height."','".$weight."','".$bloodGroup."','".$bedID."','".$trea."',0,0);" ) or die ('Problem with query' . mysqli_error($conn));
  }
  ?>
</div>
<br>
<br>


</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</body>
</html>
