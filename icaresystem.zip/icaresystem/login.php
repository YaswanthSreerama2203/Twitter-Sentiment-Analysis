<?php ob_start();
 ob_start();
 session_start();
 if(isset($_SESSION["locked"]))
 {
   $difference= time()-$_SESSION["locked"];
   if($difference>10){
     unset($_SESSION["locked"]);
     unset($_SESSION["login_attempts"]);
   }
 }
?>
<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"></script>
      <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <title>HOME</title>
  </head>
<style>
body {
    margin: 0;
    color: #6a6f8c;
    background: #ffff;
    font: 600 16px/18px 'Open Sans', sans-serif
}

.login-box {
    width: 100%;
    margin: auto;
    max-width: 400px;
    min-height: 470px;
    position: relative;
    background: url(https://images.unsplash.com/photo-1507208773393-40d9fc670acf?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1268&q=80) no-repeat center;
    box-shadow: 0 12px 15px 0 rgba(0, 0, 0, .24), 0 17px 50px 0 rgba(0, 0, 0, .19)
}

.login-snip {
    width: 100%;
    height: 100%;
    position: absolute;
    padding: 20px 70px 50px 70px;
    background: rgba(0, 77, 77, .9)
}

.login-snip .login,
.login-snip .sign-up-form {
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    position: absolute;
    transform: rotateY(180deg);
    backface-visibility: hidden;
    transition: all .4s linear
}

.login-snip .sign-in,
.login-snip .sign-up,
.login-space .group .check {
    display: none
}

.login-snip .tab,
.login-space .group .label,
.login-space .group .button {
    text-transform: uppercase
}

.login-snip .tab {
    font-size: 22px;
    margin-right: 15px;
    padding-bottom: 5px;
    margin: 0 10px 10px 0;
    display: inline-block;
    border-bottom: 2px solid transparent
}

.login-snip .sign-in:checked+.tab,
.login-snip .sign-up:checked+.tab {
    color: #fff;
    border-color: #1161ee
}

.login-space {
    min-height: 345px;
    position: relative;
    perspective: 1000px;
    transform-style: preserve-3d
}

.login-space .group {
    margin-bottom: 15px
}

.login-space .group .label,
.login-space .group .input,
.login-space .group .button {
    width: 100%;
    color: #fff;
    display: block
}

.login-space .group .input,
.login-space .group .button {
    border: none;
    padding: 15px 20px;
    border-radius: 25px;
    background: rgba(255, 255, 255, .1)
}

.login-space .group input[data-type="password"] {
    text-security: circle;
    -webkit-text-security: circle
}

.login-space .group .label {
    color: #aaa;
    font-size: 12px
}

.login-space .group .button {
    background: #1161ee
}

.login-space .group label .icon {
    width: 15px;
    height: 15px;
    border-radius: 2px;
    position: relative;
    display: inline-block;
    background: rgba(255, 255, 255, .1)
}

.login-space .group label .icon:before,
.login-space .group label .icon:after {
    content: '';
    width: 10px;
    height: 2px;
    background: #fff;
    position: absolute;
    transition: all .2s ease-in-out 0s
}

.login-space .group label .icon:before {
    left: 3px;
    width: 5px;
    bottom: 6px;
    transform: scale(0) rotate(0)
}

.login-space .group label .icon:after {
    top: 6px;
    right: 0;
    transform: scale(0) rotate(0)
}

.login-space .group .check:checked+label {
    color: #fff
}

.login-space .group .check:checked+label .icon {
    background: #1161ee
}

.login-space .group .check:checked+label .icon:before {
    transform: scale(1) rotate(45deg)
}

.login-space .group .check:checked+label .icon:after {
    transform: scale(1) rotate(-45deg)
}

.login-snip .sign-in:checked+.tab+.sign-up+.tab+.login-space .login {
    transform: rotate(0)
}

.login-snip .sign-up:checked+.tab+.login-space .sign-up-form {
    transform: rotate(0)
}

*,
:after,
:before {
    box-sizing: border-box
}

.clearfix:after,
.clearfix:before {
    content: '';
    display: table
}

.clearfix:after {
    clear: both;
    display: block
}

a {
    color: inherit;
    text-decoration: none
}

.hr {
    height: 2px;
    margin: 60px 0 50px 0;
    background: rgba(255, 255, 255, .2)
}

.foot {
    text-align: center
}

.card {
    width: 600px;

}

::placeholder {
    color: #b3b3b3
}

</style>
<body>
<div class="row">
    <div class="col-md-4 mx-auto p-2">
<br>
<br>
        <div class="card">
          <div align="center"><h1><b>Icare System<b></h1></div>
            <div class="login-box">
                <div class="login-snip"> <input id="tab-1" type="radio" name="tab" class="sign-in" checked><label for="tab-1" class="tab">Login</label> <input id="tab-2" type="radio" name="tab" class="sign-up"><label for="tab-2" class="tab">Sign Up</label>
                    <div class="login-space">
                      <form action="" method="POST">
                        <div class="login">
                            <div class="group"> <label for="empno" class="label">Worker ID</label> <input id="empno" name="empno" type="text" class="input" placeholder="Enter your Worker ID" required> </div>
                            <!--<div class="group"> <label for="user" class="label">Username</label> <input id="user" name="user" type="text" class="input" placeholder="Enter your username" required> </div>-->
                            <div class="group"> <label for="pass" class="label">Password</label> <input id="pass" name="pass" type="password" class="input" data-type="password" placeholder="Enter your password" required> </div>
                            <?php
                            if(!isset($_SESSION['login_attempts'])){
                              $_SESSION["login_attempts"]=0;
                            }
                            if($_SESSION["login_attempts"]>2){
                              $_SESSION["locked"]=time();
                              echo "<p> Please wait for 10 seconds</p>";
                            }else{?>
                            <div class="group"> <button type="submit" class="button" value="Sign In" name="sub">Submit</button> </div>
                          <?php }?>
                            <div class="hr"></div>
                            <div class="foot"> <a href="passwordre.php">Forgot Password?</a> </div>
                        </div>
                      </form>
                        <form action="" method="POST">
                        <div class="sign-up-form">
                            <div class="group"> <label for="empno1" class="label">Employee Number</label><input id="empno1" name="empno1" type="text" class="input" placeholder="Enter Employee Number" required> </div>
                            <!--<div class="group"> <label for="user1" class="label">Username</label> <input id="user1" name="user1" type="text" class="input" placeholder="Create your Username" required> </div>-->
                            <div class="group"> <label for="email" class="label">Email</label> <input id="email" name="email" type="text" class="input" placeholder="Create your Username" required> </div>
                            <div class="group"> <label for="pass1" class="label">Password</label> <input id="pass1" name="pass1" type="password" class="input" data-type="password" placeholder="Create your password" required> </div>
                            <div class="group"> <label for="pass2" class="label">Repeat Password</label> <input id="pass2" name="pass2" type="password" class="input" data-type="password" placeholder="Repeat your password" required> </div>
                            <div class="group"> <button type="submit" class="button" value="Sign Up" name="sub1">Submit</button> </div>
                        </div>
                      </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="myModal" role="dialog">
  <div class="modal-dialog">
      <!-- Modal content-->
      <div class="modal-content">
          <div class="modal-header">
              <h4 class="modal-title text-success">You can login now!!!!</h4>
          </div>
          <div class="modal-footer">
              <button type="button" id="close" class="btn btn-default" data-dismiss="modal">Close</button>
          </div>
      </div>
  </div>
</div>
<div class="modal fade" id="myModal2" role="dialog">
<div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
        <div class="modal-header">
            <h4 class="modal-title text-danger">wrong credentials!!!!</h4>
        </div>
        <div class="modal-footer">
            <button type="button" id="close1" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
    </div>
</div>
</div>
<div class="modal fade" id="myModa22" role="dialog">
<div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
        <div class="modal-header">
            <h4 class="modal-title text-danger">unauthorised user!!!!</h4>
        </div>
        <div class="modal-footer">
            <button type="button" id="close2" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
    </div>
</div>
</div>
<div class="modal fade" id="myModa32" role="dialog">
<div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
        <div class="modal-header">
            <h4 class="modal-title text-danger">type password properly!!!!</h4>
        </div>
        <div class="modal-footer">
            <button type="button" id="close3" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
    </div>
</div>
</div>
<div class="modal fade" id="myModa5" role="dialog">
<div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
        <div class="modal-header">
            <h4 class="modal-title text-danger">Your are already registered user please Login!!!!</h4>
        </div>
        <div class="modal-footer">
            <button type="button" id="close5" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
    </div>
</div>
</div>

<?php
if(isset($_POST["sub"]))
{
$en=$_POST['empno'];
//$un=$_POST['user'];
$p=$_POST['pass'];
$_SESSION['empno']=$en;
$conn = mysqli_connect("localhost", "root", "", "icare") or die("Not Connected");
$result=mysqli_query($conn, "SELECT ID,password FROM `userpassword` WHERE ID='$en' and password='$p' ") or die ('Problem with query' . mysqli_error($conn));
$row = mysqli_fetch_array($result,MYSQLI_ASSOC);
$_SESSION['empname']=$row['empname'];
$count = mysqli_num_rows($result);
if($count==0)
{
  $_SESSION["login_attempts"]+=1;
  $result=1;
}
else {
  header("Location:iCareBoard.php");
}
}
if(isset($_POST["sub1"]))
{
$conn = mysqli_connect("localhost", "root", "", "app") or die("Not Connected");
$en1=$_POST['empno1'];
//$un1=$_POST['user1'];
$email=$_POST['email'];
$p1=$_POST['pass1'];
$p2=$_POST['pass2'];
if($p1==$p2){
$conn = mysqli_connect("localhost", "root", "", "app") or die("Not Connected");
$res=mysqli_query($conn, "SELECT id,empname FROM `employeedatabase` WHERE empno='$en1'") or die ('Problem with query' . mysqli_error($conn));
$resv=mysqli_query($conn, "SELECT id FROM `employeedata` WHERE empno='$en1'") or die ('Problem with query' . mysqli_error($conn));
$row = mysqli_fetch_array($res,MYSQLI_ASSOC);
$rowv = mysqli_fetch_array($resv,MYSQLI_ASSOC);
$count = mysqli_num_rows($res);
$countv = mysqli_num_rows($resv);
if($count!=0 and $countv==0){
  $un1=$row['empname'];
  $sql1 = mysqli_query($conn, "INSERT INTO `employeedata` (`id`, `empno`,`empname`,`email`,`passwords`) VALUES ('', '". $en1 ."', '".$un1."','".$email."','".$p1."')") or die ('Problem with query' . mysqli_error($conn));
  $result=4;
}
else{
  if($countv!=0){
    $result=5;
  }else{
  $result=2;
  }
}
}
else{
  $result=3;
}
}
?>
<div> <input type="hidden" id="cd" name="cd" value="<?php echo (isset($result))?$result:' '; ?>"></div>

<script>
 $('document').ready(function(){
       if(document.getElementById("cd").value == "1"){
         	$('#myModal2').modal('toggle');
          $('#close1').on('click',function(){
             window.location = "index.php";
          	});

       }
       if(document.getElementById("cd").value == "2"){
         $('#myModa22').modal('toggle');
         $('#close2').on('click',function(){
             window.location = "index.php";
           });
       }
       if(document.getElementById("cd").value == "3"){
         $('#myModa32').modal('toggle');
         $('#close3').on('click',function(){
             window.location = "index.php";
           });
       }
       if(document.getElementById("cd").value == "4"){
         $('#myModal').modal('toggle');
         $('#close1').on('click',function(){
             window.location = "index.php";
           });
       }
       if(document.getElementById("cd").value == "5"){
         $('#myModa5').modal('toggle');
         $('#close5').on('click',function(){
             window.location = "index.php";
           });
       }
     });
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</html>
<?php ob_end_flush(); ?>
