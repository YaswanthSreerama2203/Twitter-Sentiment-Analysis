<?php
session_start();
if(isset($_POST["editbutton"])) # This if checks if the edit button is clikced and executes the below code
{
  $pid=$_POST["ID"];
  $name=$_POST["name"];
  $address=$_POST["address"];
  $DOB=$_POST["DOB"];
  $height=$_POST["height"];
  $weight=$_POST["weight"];
  $bloodGroup=$_POST["bloodGroup"];
  $bedID=$_POST["bedID"];
  $tarea=$_POST["tarea"];
  //Connection with database and execute the UPDATE query
  $conn = mysqli_connect("localhost", "root", "", "icare") or die("Not Connected");
  $role=mysqli_query($conn, "UPDATE `patientrecord` SET  `name`='".$name."',`address`='".$address."',`DOB`='".$DOB."',`height`='".$height."',`weight`='".$weight."',`bloodGroup`='".$bloodGroup."',`bedID`='".$bedID."',`treatmentArea`='".$tarea."'   WHERE `ID`= $pid;" ) or die ('Problem with query' . mysqli_error($conn));


}
if(isset($_POST["delete"])) // This if checks if the delete button is clikced and executes the below code
{
  $pid=$_POST["delete"];
  //Connection with database and execute the DELETE query
  $conn = mysqli_connect("localhost", "root", "", "icare") or die("Not Connected");
  $role=mysqli_query($conn, "DELETE FROM `patientrecord` WHERE ID = $pid" ) or die ('Problem with query' . mysqli_error($conn));


}
?>

<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<style>
body {
  font-family: "Lato", sans-serif;
}

.sidenav {
  height: 100%;
  width: 200px;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  padding-top: 20px;
}

.sidenav a {
  padding: 8px 10px 8px 16px;
  text-decoration: none;
  font-size: 25px;
  color: #818181;
  display: block;
}

.sidenav a:hover {
  color: #f1f1f1;
}

.main {
  margin-left: 200px; /* Same as the width of the sidena */
  font-size: 20px;    /* Increased text to enable scrolling */
  padding: 0px 10px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}

</style>

</head>
<body>

//Left panel implementation
  <div class="sidenav">
    <?php
    $x=$_SESSION['empno'];
    $conn = mysqli_connect("localhost", "root", "", "icare") or die("Not Connected");
    $role=mysqli_query($conn, "SELECT   profession FROM `icareuser` WHERE ID=$x " ) or die ('Problem with query' . mysqli_error($conn));
    $row = mysqli_fetch_array($role,MYSQLI_ASSOC);
    $a=$row['profession'];
    $_SESSION['role']=$a;
    ?>
    <?php if($_SESSION['role']=="admin"){?>
      <a href="ManageWorker.php">ManageWorker</a>
      <a href="login.php">Logout</a>
    <?php }if($_SESSION['role']!="admin"){ ?>
      <a href="iCareBoard.php">iCareBoard</a>
      <a href="myboard.php">MyBoard</a>
      <a href="ManagePatients.php">Create Patient</a>
      <a href="Palette.php">Palette</a>
      <a href="login.php">Logout</a>
  <?php } ?>
  </div>

  <div class="main">

  <?php
  if(isset($_POST["button1"])) /*ADD Functionality: This if checks if the ADD (button1) button is clikced and executes the below code*/
  {
  $did=$_SESSION['empno'];
  $pid=$_POST["button1"];
  $x=$_SESSION['empno'];
  $conn = mysqli_connect("localhost", "root", "", "icare") or die("Not Connected");
  $role=mysqli_query($conn, "SELECT   profession FROM `icareuser` WHERE ID=$x " ) or die ('Problem with query' . mysqli_error($conn));
  $row = mysqli_fetch_array($role,MYSQLI_ASSOC);
  $a=$row['profession'];
  $_SESSION['role']=$a;
  $conn = mysqli_connect("localhost", "root", "", "icare") or die("Not Connected");
  $res=mysqli_query($conn, "INSERT INTO `assignedpatients` (`Patient_ID`,`Worker_ID`) VALUES ('".$pid."','".$did."'); ") or die ('Problem with query' . mysqli_error($conn));
  if($a=='doc'){
    $res=mysqli_query($conn, "UPDATE `patientrecord` SET `Doc_Assigned` = 1 WHERE ID = $pid;" ) or die ('Problem with query' . mysqli_error($conn));
  }
  if($a=='Nurse'){
    $res=mysqli_query($conn, "UPDATE `patientrecord` SET `Nurse_Assigned` = 1 WHERE ID = $pid;" ) or die ('Problem with query' . mysqli_error($conn));
  }

  }
  ?>
  <!--chekcs if role of the worker is not admin-->
<?php if($_SESSION['role']!="admin"){ ?>
<h2>
    <!--Filters unassigned patients based on the geo location -->
 <form method='post' action="geocodesearch.php">

  <label for="iloc">Search by  geocode:</label>
  <select id="iloc" name="iloc">
    <option value="Denton">Denton</option>
    <option value="Austin">Austin</option>
    <option value="Plano">Plano</option>
    <option value="Frisco">Frisco</option>
  </select>
  <input class="btn btn-secondary"  type="submit">
</form>
</h2>
<!-- iCareBoard Table design and implementation-->
<!--  -->
<table >
  <thead>
  <tr>
    <th>ID</th>
    <th>name</th>
    <th>address</th>
    <th>DOB</th>
    <th>height</th>
    <th>weight</th>
    <th>bloodgroup</th>
    <th>bedID</th>
    <th>treatmentArea</th>
  </thead>

  <tbody>
  <?php

  $x=$_SESSION['empno'];
  $conn = mysqli_connect("localhost", "root", "", "icare") or die("Not Connected");
  $role=mysqli_query($conn, "SELECT   profession FROM `icareuser` WHERE ID=$x " ) or die ('Problem with query' . mysqli_error($conn));
  $row = mysqli_fetch_array($role,MYSQLI_ASSOC);
  $a=$row['profession'];
  $_SESSION['role']=$a;
  if($a=='doc'){
    $res=mysqli_query($conn, "SELECT * FROM `patientrecord` WHERE Doc_Assigned=0" ) or die ('Problem with query' . mysqli_error($conn));
  }
  if($a=='Nurse'){
    $res=mysqli_query($conn, "SELECT * FROM `patientrecord` WHERE Nurse_Assigned=0" ) or die ('Problem with query' . mysqli_error($conn));
  }




  if ($res->num_rows > 0) {
    // output data of each row
    while($row = $res->fetch_assoc()) {


  ?>

  <tr >
    <td><?php echo  $row["ID"] ;?></td>
    <td><?php echo  $row["name"] ;?></td>
    <td><?php echo  $row["address"] ;?></td>
    <td><?php echo $row["DOB"] ;?></td>
    <td><?php echo $row["height"] ;?></td>
    <td><?php echo "weight: " . $row["weight"] ;?></td>
    <td><?php echo  $row["bloodGroup"] ;?></td>
    <td><?php echo $row["bedID"] ;?></td>
    <td><?php echo  $row["treatmentArea"] ;?></td>
    <td>
      <form method='post' action="iCareBoard.php">
      <button class="btn btn-primary" type="submit" id="button1" name="button1" value=<?php echo  $row["ID"]?>>ADD</button>
    </form></td>
    <td>
      <form method='post' action="editpage.php">
      <button class="btn btn-success"  type="submit" id="editid" name="editid" value=<?php echo  $row["ID"]?>>Edit</button>
    </form></td>
    <td>
      <form method='post' action="iCareBoard.php">
      <button class="btn btn-danger" type="submit" id="delete" name="delete" value=<?php echo  $row["ID"]?>>Delete</button>
    </form></td>
  </tr>

  <?php
             }
             ?>
             </tbody>
           </table><?php }?>

</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</body>
</html>
<?php
}

else {

}
$conn->close();
?>
