<?php
  if(isset($_POST['search'])){
    $response="No data found";
    exit($response);
  }
 ?>
