<?php
require('fpdfdir/fpdf.php'); //importing fpdf.php for calling pdf class
include "config.php";
 ob_start();
session_start();
if(!(isset($_SESSION['empno']))){
  header("Location:index.php");
}
$url=(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
$url_components = parse_url($url);
parse_str($url_components['query'], $params);
$id=$params['id'];
$idn= substr($id, 3, );

$pdf = new FPDF(); //calling new PDF object
$pdf->AddPage();
$pdf->SetFont('Times','',12);
$con = mysqli_connect('localhost','root','','app');
$sql = "select * from car where id='$id'";
$result = mysqli_query($con,$sql);
while($rows=mysqli_fetch_array($result))
{
  //adding all the required information to the pdf at appropriate positions
  $pdf->SetFont('Arial','B',12);
  $pdf->Cell(180,5,"MOIL LIMITED",0,1,'C');
  $pdf->SetFont('Times','',12);
  $pdf->Cell(200,5,"MOIL Bhawan,1A Katol Road,Nagpur - 440013",0,1,'C');
  $pdf->ln(1);
  $pdf->line(5,20,200,20);
  $pdf->ln(2);
  $pdf->SetFont('Arial','B',12);
  $pdf->Cell(180,5,"REQUISITION FOR TAXI",0,0,'C');
  $pdf->ln(2);
  $pdf->SetFont('Times','',12);
  $pdf->SetXY(10, 30);
  $pdf->Cell(40,5,"1. Name and ",0,1,'L');

  $pdf->Cell(40,5,"Designation of ",0,1,'L');

  $pdf->Cell(40,5,"Requesting Officer ",0,1,'L');
  $pdf->ln(3);
  $pdf->Cell(40,5,"2. Taxi Required for ",0,1,'L');
  $pdf->Cell(40,5,"Name and Designation of Guest ",0,1,'L');
  $pdf->ln(3);
  $pdf->Cell(40,5,"a. Excepted Time and ",0,1,'C');
  $pdf->Cell(40,5,"Date of Departure ",0,1,'C');
  $pdf->ln(1);
  $pdf->Cell(40,5,"b. Excepted Time and ",0,1,'C');
  $pdf->Cell(40,5,"Date of return ",0,1,'C');
  $pdf->ln(3);
  $pdf->Cell(40,5,"3. Place and Mines o be visited",0,1,'L');
  $pdf->ln(3);
  $pdf->Cell(40,5,"4. Adress at which Taxi should Report ",0,1,'L');
  $pdf->ln(3);
  $pdf->Cell(40,5,"Telehone/phone number",0,1,'L');
  $pdf->ln(3);
  $pdf->Cell(40,5,"5. Purpose of visit",0,1,'L');
  $pdf->ln(3);
  $pdf->Cell(40,5,"6. Any other special Insructions",0,1,'L');
  $pdf->ln(3);
  $pdf->Cell(40,5,"7. Taxi A.C or NON A.C",0,1,'L');
  $pdf->ln(3);

  $pdf->SetXY(90, 30);
  $pdf->SetFont('Times','B',12);
  $pdf->Cell(40,5,$rows['empname'],0,1,'L');
  $pdf->SetXY(90, 36);
  $pdf->Cell(40,5,$rows['designation'],0,2,'L');
  $pdf->SetXY(90, 50);
  $pdf->Cell(40,5,$rows['guestname'],0,1,'L');
  $pdf->SetXY(90, 62);
  $pdf->Cell(40,5,$rows['expecteddod']." ".$rows['expectedtod'],0,1,'L');
  $pdf->SetXY(90, 72);
  $pdf->Cell(40,5,$rows['expecteddoa']." ".$rows['expectedtoa'],0,1,'L');
  $pdf->SetXY(90, 82);
  $pdf->Cell(40,5,$rows['mines'],0,1,'L');
  $pdf->SetXY(90, 92);
  $pdf->Cell(40,5,$rows['adresstaxi'],0,1,'L');
  $pdf->SetXY(90, 100);
  $pdf->Cell(40,5,$rows['mobilenumber'],0,1,'L');
  $pdf->SetXY(90, 108);
  $pdf->Cell(40,5,$rows['purpose'],0,1,'L');
  $pdf->SetXY(90, 116);
  $pdf->Cell(40,5,$rows['info'],0,1,'L');
  $pdf->SetXY(90, 124);
  $pdf->Cell(40,5,$rows['taxitype'],0,1,'L');


  $pdf->ln(6);






}


    $pdf->Output();








 ob_end_flush(); ?>
