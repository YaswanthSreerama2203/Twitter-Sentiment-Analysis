<?php
session_start();

if(isset($_POST["editbutton"]))
{
  $pid=$_POST["ID"];
  $name=$_POST["name"];
  $address=$_POST["address"];
  $DOB=$_POST["DOB"];
  $height=$_POST["height"];
  $weight=$_POST["weight"];
  $bloodGroup=$_POST["bloodGroup"];
  $bedID=$_POST["bedID"];
  $tarea=$_POST["tarea"];
  $conn = mysqli_connect("localhost", "root", "", "icare") or die("Not Connected");
  $role=mysqli_query($conn, "UPDATE `patientrecord` SET  `name`='".$name."',`address`='".$address."',`DOB`='".$DOB."',`height`='".$height."',`weight`='".$weight."',`bloodGroup`='".$bloodGroup."',`bedID`='".$bedID."',`treatmentArea`='".$tarea."'   WHERE `ID`= $pid;" ) or die ('Problem with query' . mysqli_error($conn));


}
?>


<!DOCTYPE html>
<html>
<head>
<style>
body {
  font-family: "Lato", sans-serif;
}
.card {
  /* Add shadows to create the "card" effect */
  box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
  transition: 0.3s;
}

/* On mouse-over, add a deeper shadow */
.card:hover {
  box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2);
}

/* Add some padding inside the card container */
.container {
  padding: 2px 16px;
}

.sidenav {
  height: 100%;
  width: 200px;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  padding-top: 20px;
}

.sidenav a {
  padding: 8px 10px 8px 16px;
  text-decoration: none;
  font-size: 25px;
  color: #818181;
  display: block;
}

.sidenav a:hover {
  color: #f1f1f1;
}

.main {
  margin-left: 200px; /* Same as the width of the sidenav */
  font-size: 20px; /* Increased text to enable scrolling */
  padding: 0px 10px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
</head>
<body>
  <div class="sidenav">
    <a href="EditworkerTable.php">Manage Worker</a>
    <a href="ManageWorker.php">Add Worker</a>
    <a href="login.php">Logout</a>


  </div>

<div class="main " align="center" >
  <div class="card">
  <!DOCTYPE html>
  <html>
  <head>
  <title>Page Title</title>
  </head>
  <body>
  <!--Page Design-->
  <h2>Create New Worker</h2>
  <form method='post' action="ManageWorker.php">
      <p>
      <label>name : <input type="text" id="name" name="name" /></label>
    </p>

    <p>
        <label>Hired Date &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp<input type="date"  name="hdate" id="hdate"></label>
      </p>
      <p>
          <label>Finished Date &nbsp &nbsp &nbsp &nbsp &nbsp &nbsp<input type="date"  name="fdate" id="fdate"></label>
        </p>

        <p>
        <label>Email : <input type="text" id="email" name="email"/></label>
      </p>
      <p>
        <label for="profession">Profession  :</label>
<select id="prof" name="prof" required>
  <option value="None"></option>
  <option value="doc">Doctor</option>
  <option value="Nurse">Nurse</option>

</select>
      </p>
      <p>
      <label>Password : <input type="text" id="pass" name="pass" /></label>
    </p>


  <p>
         <button type="submit" id="button1" name="button1"  >ADD</button>&nbsp &nbsp

    </p>


  </form>
  </body>
  </html>
  <?php
  if(isset($_POST["button1"]))  //Check condition iF ADD button Clicked
  {
    $name=$_POST["name"];
    $hdate=$_POST["hdate"];
    $fdate=$_POST["fdate"];
    $email=$_POST["email"];
    $prof=$_POST["prof"];
    $pass=$_POST["pass"];
    $conn = mysqli_connect("localhost", "root", "", "icare") or die("Not Connected");
    $role=mysqli_query($conn, "INSERT INTO `icareuser` (`name`,`profession`,`Email`,`HiredDate`,`FinishedDate`) VALUES ('".$name."', '".$prof."','".$email."', '".$hdate."','".$fdate."');" ) or die ('Problem with query' . mysqli_error($conn));
    $f=mysqli_query($conn, "SELECT   ID FROM `icareuser` WHERE `name`='".$name."' " ) or die ('Problem with query' . mysqli_error($conn));
    $f1 = mysqli_fetch_array($f,MYSQLI_ASSOC);
    $wid=$f1['ID'];
    $k=mysqli_query($conn, "INSERT INTO `userpassword` (`ID`,`name`,`password`) VALUES ('".$wid."','".$name."', '".$pass."');" ) or die ('Problem with query' . mysqli_error($conn));

  }
  ?>
</div>
<br>
<br>


</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</body>
</html>
