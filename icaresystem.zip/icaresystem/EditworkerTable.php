<?php
session_start();

if(isset($_POST["editworkerbutton"]))
{
  $wid=$_POST["editworkerbutton"];
  echo $wid;
  $name=$_POST["name"];
  $prof=$_POST["prof"];
  $email=$_POST["email"];
  $hdate=$_POST["hdate"];
  $fdate=$_POST["fdate"];
  $conn = mysqli_connect("localhost", "root", "", "icare") or die("Not Connected");
  $role=mysqli_query($conn, "UPDATE `icareuser` SET  `name`='".$name."',`profession`='".$prof."',`Email`='".$email."',`HiredDate`='".$hdate."',`FinishedDate`='".$fdate."' WHERE `ID`=$wid" ) or die ('Problem with query' . mysqli_error($conn));


}
?>

<!DOCTYPE html>
<html>
<head>
<style>
body {
  font-family: "Lato", sans-serif;
}

.sidenav {
  height: 100%;
  width: 200px;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  padding-top: 20px;
}

.sidenav a {
  padding: 8px 10px 8px 16px;
  text-decoration: none;
  font-size: 25px;
  color: #818181;
  display: block;
}

.sidenav a:hover {
  color: #f1f1f1;
}

.main {
  margin-left: 200px; /* Same as the width of the sidenav */
  font-size: 20px; /* Increased text to enable scrolling */
  padding: 0px 10px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
</head>
<body>

<!-- In this admin can edit all worker details -->

  <div class="sidenav">
    <?php
    $x=$_SESSION['empno'];
    $conn = mysqli_connect("localhost", "root", "", "icare") or die("Not Connected");
    $role=mysqli_query($conn, "SELECT   profession FROM `icareuser` WHERE ID=$x " ) or die ('Problem with query' . mysqli_error($conn));
    $row = mysqli_fetch_array($role,MYSQLI_ASSOC);
    $a=$row['profession'];
    $_SESSION['role']=$a;
    ?>
    <?php if($_SESSION['role']=="admin"){?> //left Panel Naviagation
      <a href="EditworkerTable.php">Manage Worker</a>
      <a href="ManageWorker.php">Add Worker</a>
      <a href="login.php">Logout</a>
<?php } ?>
  </div>

  <div class="main">

    <?php
    $x=$_SESSION['empno'];
    $conn = mysqli_connect("localhost", "root", "", "icare") or die("Not Connected");
    $role=mysqli_query($conn, "SELECT   profession FROM `icareuser` WHERE ID=$x " ) or die ('Problem with query' . mysqli_error($conn));
    $row = mysqli_fetch_array($role,MYSQLI_ASSOC);
    $a=$row['profession'];
    $_SESSION['role']=$a;
    ?>
<?php if($_SESSION['role']=="admin"){ ?>


<table>
  <thead>
  <tr>
    <!-- Table attributes -->
    <th>ID</th>
    <th>name</th>
    <th>Profession</th>
    <th>Email</th>
    <th>HierdDate</th>
    <th>FinishedDate</th>
  </thead>

  <tbody>
  <?php

  $x=$_SESSION['empno'];
  $conn = mysqli_connect("localhost", "root", "", "icare") or die("Not Connected");
  $role=mysqli_query($conn, "SELECT   profession FROM `icareuser` WHERE ID=$x " ) or die ('Problem with query' . mysqli_error($conn));
  $row = mysqli_fetch_array($role,MYSQLI_ASSOC);
  $a=$row['profession'];
  $_SESSION['role']=$a;
    $res=mysqli_query($conn, "SELECT * FROM `icareuser`" ) or die ('Problem with query' . mysqli_error($conn));




  if ($res->num_rows > 0) {
    // output data of each row
    while($row = $res->fetch_assoc()) {


  ?>

  <tr>
    <td><?php echo  $row["ID"] ;?></td>
    <td><?php echo  $row["name"] ;?></td>
    <td><?php echo  $row["profession"] ;?></td>
    <td><?php echo $row["Email"] ;?></td>
    <td><?php echo $row["HiredDate"] ;?></td>
    <td><?php echo $row["FinishedDate"] ;?></td>

    <td>
      <form method='post' action="editworkerform.php">
      <button type="submit" id="button1" name="button1" value=<?php echo  $row["ID"]?>>Edit</button>
    </form></td>
  </tr>

  <?php
             }
             ?>
             </tbody>
           </table><?php }?>

</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</body>
</html>
<?php
}

else {

}
$conn->close();
?>
