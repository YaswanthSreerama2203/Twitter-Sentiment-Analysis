<?php
session_start();
?>
<?php
  if(isset($_POST["addbutton"]))
{
  $pid=$_POST["addbutton"];
  $wid=$_SESSION['empno'];
  $tdate=$_POST["tdate"];
  $desc=$_POST["desc"];
  $conn = mysqli_connect("localhost", "root", "", "icare") or die("Not Connected");
  $role=mysqli_query($conn, "INSERT INTO `treatmentdetails` (`worker_id`,`patient_id`,`treat_date`,`Description`) VALUES ('".$wid."','".$pid."','".$tdate."','".$desc."')" ) or die ('Problem with query' . mysqli_error($conn));
}
?>
<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

<style>
body {
  font-family: "Lato", sans-serif;
}

.sidenav {
  height: 100%;
  width: 200px;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  padding-top: 20px;
}

.sidenav a {
  padding: 6px 8px 6px 16px;
  text-decoration: none;
  font-size: 25px;
  color: #818181;
  display: block;
}

.sidenav a:hover {
  color: #f1f1f1;
}

.main {
  margin-left: 200px; /* Same as the width of the sidenav */
  font-size: 28px; /* Increased text to enable scrolling */
  padding: 0px 10px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
</head>
<body>
  <!-- Left Panel Navigation -->
  <div class="sidenav">
    
    <a href="iCareBoard.php">iCareBoard</a>
    <a href="myboard.php">MyBoard</a>
    <a href="ManagePatients.php">Create Patient</a>
    <a href="Palette.php">Palette</a>
    <a href="login.php">Logout</a>
  </div>

<div class="main">
  <table>   <!-- Table Attributes -->
    <thead>
    <tr>
      <th>ID</th>
      <th>name</th>
      <th>address</th>
      <th>DOB</th>
      <th>height</th>
      <th>weight</th>
      <th>bloodgroup</th>
      <th>bedID</th>
      <th>treatmentArea</th>
    </thead>
    <tbody>
  <?php
  $x=$_SESSION['empno'];
  if(isset($_POST["button1"]))
  //Unassign function where worker can unassing the patient and re-routes to the same page
  {
  $did=$_SESSION['empno'];
  $pid=$_POST["button1"];
  $conn = mysqli_connect("localhost", "root", "", "icare") or die("Not Connected");
  $role=mysqli_query($conn, "SELECT   profession FROM `icareuser` WHERE ID=$x " ) or die ('Problem with query' . mysqli_error($conn));
  $role_row = mysqli_fetch_array($role,MYSQLI_ASSOC);
  $a=$role_row['profession'];
  $res=mysqli_query($conn, "DELETE FROM `assignedpatients` WHERE `Patient_ID`='".$pid."'; ") or die ('Problem with query' . mysqli_error($conn));
  //checks if the doctor is assigning, then nurse shouldn't update maintaining concurrency
  if($a=='doc'){
    $res=mysqli_query($conn, "UPDATE `patientrecord` SET `Doc_Assigned` = 0 WHERE ID = $pid;" ) or die ('Problem with query' . mysqli_error($conn));
  }
  //checks if the nurse is assigning, then doctor shouldn't update maintaining concurrency
  if($a=='Nurse'){
    $res=mysqli_query($conn, "UPDATE `patientrecord` SET `Nurse_Assigned` = 0 WHERE ID = $pid;" ) or die ('Problem with query' . mysqli_error($conn));
  }

  }

  $conn = mysqli_connect("localhost", "root", "", "icare") or die("Not Connected");
  $role=mysqli_query($conn, "SELECT   Patient_ID FROM `assignedpatients` WHERE Worker_ID=$x " ) or die ('Problem with query' . mysqli_error($conn));

  while($row = $role->fetch_assoc()) {

      $k=$row["Patient_ID"];
      $r=$_SESSION['role'];
      if($r=='doc'){
        $result=mysqli_query($conn, "SELECT   * FROM `patientrecord` WHERE ID=$k and Doc_Assigned=1;" ) or die ('Problem with query' . mysqli_error($conn));
      }
      if($r=='Nurse'){
        $result=mysqli_query($conn, "SELECT   * FROM `patientrecord` WHERE ID=$k and  Nurse_Assigned=1;" ) or die ('Problem with query' . mysqli_error($conn));
      }
      while($row1 = $result->fetch_assoc()) {
        ?>
        <tr>
          <td><?php echo  $row1["ID"] ;?></td>
          <td><?php echo  $row1["name"] ;?></td>
          <td><?php echo  $row1["address"] ;?></td>
          <td><?php echo $row1["DOB"] ;?></td>
          <td><?php echo $row1["height"] ;?></td>
          <td><?php echo $row1["weight"] ;?></td>
          <td><?php echo  $row1["bloodGroup"] ;?></td>
          <td><?php echo $row1["bedID"] ;?></td>
          <td><?php echo  $row1["treatmentArea"] ;?></td>
          <td>
            <form method='post' action="myboard.php">
            <button class="btn btn-primary" type="submit" id="button1" name="button1" value=<?php echo  $row1["ID"]?>>Unassign</button>
          </form></td>
          <td>
            <form method='post' action="treat.php">
            <button class="btn btn-success" type="submit" id="button2" name="button2" value=<?php echo  $row1["ID"]?>>Treat</button>
          </form></td>
        </tr>
        <?php
        }

      }

    ?>


</tbody>
</table>
</div>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</body>
</html>
