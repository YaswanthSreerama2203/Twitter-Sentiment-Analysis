
<?php
session_start();

if(isset($_POST["editbutton"])) //check if edit doc button is clicked
{
  $pid=$_POST["ID"];
  $name=$_POST["name"];
  $address=$_POST["address"];
  $DOB=$_POST["DOB"];
  $height=$_POST["height"];
  $weight=$_POST["weight"];
  $bloodGroup=$_POST["bloodGroup"];
  $bedID=$_POST["bedID"];
  $tarea=$_POST["tarea"];
//connection to the database
  $conn = mysqli_connect("localhost", "root", "", "icare") or die("Not Connected");
  $role=mysqli_query($conn, "UPDATE `patientrecord` SET  `name`='".$name."',`address`='".$address."',`DOB`='".$DOB."',`height`='".$height."',`weight`='".$weight."',`bloodGroup`='".$bloodGroup."',`bedID`='".$bedID."',`treatmentArea`='".$tarea."'   WHERE `ID`= $pid;" ) or die ('Problem with query' . mysqli_error($conn));


}
if(isset($_POST["delete"])) //check if delete doc button is clicked
{
  $pid=$_POST["delete"];
  $conn = mysqli_connect("localhost", "root", "", "icare") or die("Not Connected");
  //connection to the database
  $role=mysqli_query($conn, "DELETE FROM `patientrecord` WHERE ID = $pid" ) or die ('Problem with query' . mysqli_error($conn));


}
?>

<!DOCTYPE html>
<html>
<head>
<style>
body {
  font-family: "Lato", sans-serif;
}

.sidenav {
  height: 100%;
  width: 200px;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  padding-top: 20px;
}

.sidenav a {
  padding: 8px 10px 8px 16px;
  text-decoration: none;
  font-size: 25px;
  color: #818181;
  display: block;
}

.sidenav a:hover {
  color: #f1f1f1;
}

.main {
  margin-left: 200px; /* Same as the width of the sidenav */
  font-size: 20px; /* Increased text to enable scrolling */
  padding: 0px 10px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}

</style>

</head>
<body>

  <!-- To Edit already existing documents of the patients -->
  <div class="sidenav">
    <?php //fetches the worker profession from icareuser
    $x=$_SESSION['empno'];
    $conn = mysqli_connect("localhost", "root", "", "icare") or die("Not Connected");
    $role=mysqli_query($conn, "SELECT   profession FROM `icareuser` WHERE ID=$x " ) or die ('Problem with query' . mysqli_error($conn));
    $row = mysqli_fetch_array($role,MYSQLI_ASSOC);
    $a=$row['profession'];
    $_SESSION['role']=$a;
    ?>
    <?php if($_SESSION['role']=="admin"){?>
      <a href="ManageWorker.php">ManageWorker</a>
      <a href="login.php">Logout</a>
    <?php }if($_SESSION['role']!="admin"){ ?>
      <a href="iCareBoard.php">iCareBoard</a>
      <a href="myboard.php">MyBoard</a>
      <a href="ManagePatients.php">Create Patient</a>
      <a href="Palette.php">Palette</a>
      <a href="login.php">Logout</a>
  <?php } ?>
  </div>

  <div class="main">
    <h2>
     <form action="Palette.php"> <!-- Back function -->
    <button type="submit" id="button1" name="button1" >Back </button>
    </form>
    </h2>
    <?php
    if(isset($_POST["edit"]))
      $pid=$_POST["edit"];

      {
        ?>
      <div>
        <table>
          <thead>
          <tr>
            <th>DocID</th>
            <th>DOC Name</th>
            <th>text</th>
          </thead>

          <tbody>
          <?php
          //Edit boton functionality
          $x=$_POST["edit"];
          $conn = mysqli_connect("localhost", "root", "", "icare") or die("Not Connected");
          $res=mysqli_query($conn, "SELECT   * FROM `documentmetadata` WHERE patient_id=$x " ) or die ('Problem with query' . mysqli_error($conn));

          if ($res->num_rows > 0) {

            // output data of each row
            while($row = $res->fetch_assoc()) {


          ?>

          <tr>
            <td><?php echo  $row["doc_id"] ;?></td>
            <td><?php echo  $row["doc_name"] ;?></td>
            <td><?php echo  $row["text"] ;?></td>

            <td>
              <form method='post' action="editdocform.php">
              <button type="submit" id="doceditbutton" name="doceditbutton" value=<?php echo   $row["doc_id"] ;?>>EDIT</button>
            </form></td>

          </tr>

          <?php
          }
                     ?>
                     </tbody>
                   </table><?php
                  }?>



      <?php

     } ?>


    </div>


</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</body>
</html>
<?php

$conn->close();
?>
