<?php
require('fpdfdir/fpdf.php'); //importing fpdf.php for calling pdf class
ob_start();
session_start();
?>
<html>
<head>
</head>
<body>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
<?php if(isset($_POST["createdoc"]))
{
$pid=$_POST["createdoc"];
$x=$_SESSION['empno'];
$conn = mysqli_connect("localhost", "root", "", "icare") or die("Not Connected");
$res=mysqli_query($conn, "SELECT   * FROM `patientrecord` WHERE ID=$pid " ) or die ('Problem with query' . mysqli_error($conn));
$row = mysqli_fetch_array($res,MYSQLI_ASSOC);
$name=	$row["name"];
$address=	$row["address"];
$DOB=	$row["DOB"];
$height=	$row["height"];
$weight=	$row["weight"];
$Bloodgroup=	$row["bloodGroup"];
$bid=	$row["bedID"];
$tarea=	$row["treatmentArea"];
$dname=$_POST["dname"];
$DOC=$_POST["DOC"];
$text=$_POST["text"];
$drugpres=$_POST["pres"];
$wname=mysqli_query($conn, "SELECT * FROM `icareuser` WHERE ID=$x" ) or die ('Problem with query' . mysqli_error($conn));
$wname = mysqli_fetch_array($wname,MYSQLI_ASSOC);
$wname=$row['name'];
$up=mysqli_query($conn, "INSERT INTO `documentmetadata`(`doc_name`,`DOC`,`text`,`patient_id`,`worker_id`,`drugs`) VALUES ('".$dname."','".$DOC."','".$text."','".$pid."','".$x."','".$drugpres."' ); " ) or die ('Problem with query' . mysqli_error($conn));
$pdf = new FPDF(); //calling new PDF object
 ob_clean();
$pdf->AddPage();
//adding all the required information to the pdf at appropriate positions
$pdf->SetFont('Times','',12);
$pdf->SetFont('Arial','B',12);
$pdf->Cell(180,5,"ICARE DOCUMENT",0,1,'C');
$pdf->Cell(180  ,10,$dname,0,1,'C');
$pdf->ln(3);
$pdf->Cell(190,10,$DOC,0,0,'R');
$pdf->ln(5);
$pdf->Cell(45,10,"PATIENT ID:",0,0,'L');
$pdf->Cell(40,10,$pid,0,1,'L');
$pdf->ln(3);
$pdf->Cell(45,10,"PATIENT NAME:",0,0,'L');
$pdf->Cell(40,10,$name,0,1,'L');
$pdf->ln(3);
$pdf->Cell(45,10,"PATIENT Adress:",0,0,'L');
$pdf->Cell(40,10,$address,0,1,'L');
$pdf->ln(3);
$pdf->Cell(45,10,"Date of Birth:",0,0,'L');
$pdf->Cell(40,10,$DOB,0,1,'L');
$pdf->ln(3);
$pdf->Cell(45,10,"Height:",0,0,'L');
$pdf->Cell(40,10,$height,0,1,'L');
$pdf->ln(3);
$pdf->Cell(45,10,"Weight:",0,0,'L');
$pdf->Cell(40,10,$weight,0,1,'L');
$pdf->ln(3);
$pdf->Cell(45,10,"Blood Group:",0,0,'L');
$pdf->Cell(40,10,$Bloodgroup,0,1,'L');
$pdf->ln(3);
$pdf->Cell(45,10,"Bed ID:",0,0,'L');
$pdf->Cell(40,10,$bid,0,1,'L');
$pdf->ln(3);
$pdf->Cell(45,10,"Treatment Area:",0,0,'L');
$pdf->Cell(40,10,$tarea,0,1,'L');
$pdf->ln(3);
$pdf->Cell(45,10,"Descripton:",0,0,'L');
$pdf->Cell(40,10,$text,0,1,'L');
$pdf->ln(3);
$pdf->Cell(45,10,"Drug Prescription:",0,0,'L');
$pdf->Cell(40,10,$drugpres,0,1,'L');
$pdf->ln(3);
$pdf->Cell(180,10,"TreatedBY:",0,0,'R');
$pdf->ln(4);
$pdf->Cell(180,10,$wname,0,1,'R');
$pdf->ln(3);

$pdf->Output();
}
?>

?>
<?php if(isset($_POST["Editdocbutton"]))
{
$x=$_SESSION['empno'];
$did=$_POST["Editdocbutton"];
$dom=$_POST["DOM"];
$dname=$_POST["dname"];
$addtext=$_POST["text"];
$x=$_SESSION['empno'];
$conn = mysqli_connect("localhost", "root", "", "icare") or die("Not Connected");
$wname=mysqli_query($conn, "SELECT * FROM `icareuser` WHERE ID=$x" ) or die ('Problem with query' . mysqli_error($conn));
$wname = mysqli_fetch_array($wname,MYSQLI_ASSOC);
$wname=$wname['name'];
$updatedoc=mysqli_query($conn, "INSERT INTO `documentmetadata`(`doc_name`,`text`) VALUES ('".$dname."','".$addtext."')" ) or die ('Problem with query' . mysqli_error($conn));
$update=mysqli_query($conn, "INSERT INTO `modhistory`(`docid`, `moddate`, `text`) VALUES ('".$did."','".$dom."','".$addtext."')" ) or die ('Problem with query' . mysqli_error($conn));
$res=mysqli_query($conn, "SELECT   * FROM `documentmetadata` WHERE doc_id=$did " ) or die ('Problem with query' . mysqli_error($conn));
$drow = mysqli_fetch_array($res,MYSQLI_ASSOC);
$pid=$drow["patient_id"];
$drug=$drow["drugs"];
$res=mysqli_query($conn, "SELECT   * FROM `patientrecord` WHERE ID=$pid " ) or die ('Problem with query' . mysqli_error($conn));
$row = mysqli_fetch_array($res,MYSQLI_ASSOC);
$name=	$row["name"];
$address=	$row["address"];
$DOB=	$row["DOB"];
$height=	$row["height"];
$weight=	$row["weight"];
$Bloodgroup=	$row["bloodGroup"];
$bid=	$row["bedID"];
$tarea=	$row["treatmentArea"];
$pdf = new FPDF();
 ob_clean();
$pdf->AddPage();
$pdf->SetFont('Times','',12);
$pdf->SetFont('Arial','B',12);
$pdf->Cell(180,5,"ICARE DOCUMENT",0,1,'C');
$pdf->Cell(180,10,$dname,0,1,'C');
$pdf->ln(3);
$pdf->Cell(190,10,$dom,0,0,'R');
$pdf->ln(5);
$pdf->Cell(45,10,"PATIENT ID:",0,0,'L');
$pdf->Cell(40,10,$pid,0,1,'L');
$pdf->ln(3);
$pdf->Cell(45,10,"PATIENT NAME:",0,0,'L');
$pdf->Cell(40,10,$name,0,1,'L');
$pdf->ln(3);
$pdf->Cell(45,10,"PATIENT Adress:",0,0,'L');
$pdf->Cell(40,10,$address,0,1,'L');
$pdf->ln(3);
$pdf->Cell(45,10,"Date of Birth:",0,0,'L');
$pdf->Cell(40,10,$DOB,0,1,'L');
$pdf->ln(3);
$pdf->Cell(45,10,"Height:",0,0,'L');
$pdf->Cell(40,10,$height,0,1,'L');
$pdf->ln(3);
$pdf->Cell(45,10,"Weight:",0,0,'L');
$pdf->Cell(40,10,$weight,0,1,'L');
$pdf->ln(3);
$pdf->Cell(45,10,"Blood Group:",0,0,'L');
$pdf->Cell(40,10,$Bloodgroup,0,1,'L');
$pdf->ln(3);
$pdf->Cell(45,10,"Bed ID:",0,0,'L');
$pdf->Cell(40,10,$bid,0,1,'L');
$pdf->ln(3);
$pdf->Cell(45,10,"Treatment Area:",0,0,'L');
$pdf->Cell(40,10,$tarea,0,1,'L');
$pdf->ln(3);
$pdf->Cell(45,10,"Descripton:",0,0,'L');
$pdf->Cell(40,10,$addtext,0,1,'L');
$pdf->ln(3);
$pdf->Cell(45,10,"Drug Prescription:",0,0,'L');
$pdf->Cell(40,10,$drug,0,1,'L');
$pdf->ln(3);
$pdf->Cell(180,10,"TreatedBY:",0,0,'R');
$pdf->ln(4);
$pdf->Cell(180,10,$wname,0,1,'R');
$pdf->ln(3);

$pdf->Output();
}
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</body>
</body>
</html>
<?php

ob_end_flush();
$conn->close();
?>
