<?php
session_start();

$conn = mysqli_connect("localhost", "root", "", "icare") or die("Not Connected");
$res=mysqli_query($conn, "INSERT INTO `assignedpatients`VALUES ($_POST["userid"],$_SESSION['empno']); ") or die ('Problem with query' . mysqli_error($conn));
?>
<?php requires "iCareBoard.php"; ?>
<?php
$worker_id="";
$patient_id="";
function addRecord(){
  global $conn
  if(isset($_POST['add'])){
    $worker_id=$_SESSION['empno']
    $patient_id=$_POST['patient_id']
    $query="INSERT INTO assignedpatients(Patient_ID,Worker_ID) VALUES(patient_id,worker_id)";
    $run=mysqli_query($conn,$query)
    if($run ==True){

    }
  }
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Page Title</title>
</head>
<body>
<h2>Welcome To GFG</h2>
<form>


<p>
    <label>Username : <input type="text" /></label>
  </p>




<p>
    <label>Password : <input type="password" /></label>
  </p>




<p>
     <button type="submit">Submit</button>
  </p>


</form>
</body>
</html>
