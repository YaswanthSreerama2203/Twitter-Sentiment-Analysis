<?php //Ading the image functionality to the document
if(isset($_POST["submit"])){
  $file=$_FILES["img"];
  $filename=$file["name"];
  $a='images/';
  $path=$a.$filename;
  require('fpdfdir/fpdf.php');
  $pdf=new FPDF();
$pdf->AddPage(); //PageStart 
$pdf->Image($path,70, 10 );
$pdf->Output();
}
?>
